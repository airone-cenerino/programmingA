public final class Mutex {
	
	private boolean busy = false;
	
	public synchronized void lock() {
		
	}
	
	public synchronized void unlock() {
		
	}
}
