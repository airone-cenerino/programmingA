import java.io.*;
public class FileCopy {
	public static void main(String[] args) {
		int data = 0;
		try {
			InputStream is= new BufferedInputStream(new FileInputStream(args[0]));
			OutputStream os= new BufferedOutputStream(new FileOutputStream(args[1]));
			while((data = is.read()) != -1) {
				os.write(data);
			}
			is.close();
			os.close();
		} catch(Exception e) {
			// Throwing new RuntimeException by wrapping original exception
			throw new RuntimeException(e);
		}
	}
}